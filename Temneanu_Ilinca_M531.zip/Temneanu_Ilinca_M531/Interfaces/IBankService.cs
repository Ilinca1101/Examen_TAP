﻿
using System.Collections.Generic;
using Temneanu_Ilinca_M531.Enteties;
namespace Temneanu_Ilinca_M531.Interfaces
{
   

    public interface IBankService
    {
        void AddClient(Banca banca, Client client);
        void RemoveClient(Banca banca, Client client);
        void UpdateBankData(Banca banca, string newName, Adresa newAddress);
        void DisplayClients(Banca banca);
        List<Client> FilterClients(Banca banca, string nume = null, string strada = null, int numar =0, int apartament =0, int tipCredit =0);
    }
}
