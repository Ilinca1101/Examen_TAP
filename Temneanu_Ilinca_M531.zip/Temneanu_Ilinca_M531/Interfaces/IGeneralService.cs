﻿
using System.Collections.Generic;
using Temneanu_Ilinca_M531.Enteties;

namespace Temneanu_Ilinca_M531.Interfaces
{
    
    public interface IGeneralService
    {
        void MoveClient(Banca fromBank, Banca toBank, Client client);
        bool SameClient(Client client, List<Banca> banci);
    }

}
