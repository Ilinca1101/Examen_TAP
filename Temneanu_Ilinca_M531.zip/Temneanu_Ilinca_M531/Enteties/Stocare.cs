﻿namespace Temneanu_Ilinca_M531.Enteties
{
    public static class Stocare
    {
        public static List<Banca> Banci { get; private set; }

        static Stocare()
        {
            Banci = new List<Banca>
        {
            new Banca("Banca 1", new Adresa("Strada 1", "22", "5"), new List<Client>
            {
                new Client("Client 1", new Adresa("Strada 1", "31",  "11")),
                new Client("Client 2", new Adresa("Strada 2", "41", "3"))
            }),
            new Banca("Banca 2", new Adresa("Strada 2", "106", "2"), new List<Client>
            {
                new Client("Client 3", new Adresa("Strada 1", "44", "8")),
                new Client("Client 4", new Adresa("Strada 2", "35", "10"))
            })
        };
        }
    }
}
