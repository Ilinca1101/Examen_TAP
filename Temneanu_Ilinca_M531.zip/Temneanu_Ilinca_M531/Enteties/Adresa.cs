﻿namespace Temneanu_Ilinca_M531.Enteties
{
    public class Adresa
    {
        private string v1;
        private string v2;
        private string v3;

        public int Id { get; set; }
        public string Strada { get; set; }
        public int Numar {  get; set; }
        public int Apartament {  get; set; }

        public Adresa( string strada, int numar, int apartament)
        {
            
            Strada = strada;
            this.Apartament = apartament;
            this.Numar = numar;
          
        }

        public Adresa(string v1, string v2, string v3)
        {
            this.v1 = v1;
            this.v2 = v2;
            this.v3 = v3;
        }
    }
}
