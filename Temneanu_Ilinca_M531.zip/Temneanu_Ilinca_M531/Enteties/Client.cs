﻿namespace Temneanu_Ilinca_M531.Enteties
{
    public class Client
    {
        public int Id { get; set; }
        public string Nume { get; set; }
        public string Prenume { get; set; }
        public int DataNasterii { get; set; }
        public Adresa AdresaClient { get; set; }
        public int TipCredit { get; set; }
        public Client(string nume, Adresa adresa)
        {
            Nume = nume;
            AdresaClient = adresa;

        }

    }
}
