﻿namespace Temneanu_Ilinca_M531.Enteties
{
    public class Banca
    {
        public int Id { get; set; }
        public string Nume { get; set; }
        public Adresa AdresaBanca { get; set; }
        public string ListaClienti { get; set; }
        public int Dobanda { get; set; }
        public List<Client> Clienti { get; set; }
        public Banca(string nume, Adresa adresa, List<Client> clienti) 
        {
            Nume = nume;
            AdresaBanca = adresa;
            Clienti = clienti;
        }
    }
}
