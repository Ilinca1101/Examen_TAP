﻿using Temneanu_Ilinca_M531.Enteties;
using Temneanu_Ilinca_M531.Interfaces;

namespace Temneanu_Ilinca_M531.Services
{
    public class GeneralService: IGeneralService
    {
        public void MoveClient(Banca fromBank, Banca toBank, Client client)
        {
            if (fromBank.Clienti.Contains(client))
            {
                fromBank.Clienti.Remove(client);
                toBank.Clienti.Add(client);
            }
        }

        public bool SameClient(Client client, List<Banca> banci)
        {
            return banci.Count(banca => banca.Clienti.Contains(client)) > 1;
        }
    }
}
