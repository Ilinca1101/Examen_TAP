﻿using System.Linq;
using Temneanu_Ilinca_M531.Enteties;
using Temneanu_Ilinca_M531.Interfaces;

namespace Temneanu_Ilinca_M531.Services
{
   

    public class BankService: IBankService
    {
        public void AddClient(Banca banca, Client client)
        {
            banca.Clienti.Add(client);
        }

        public void RemoveClient(Banca banca, Client client)
        {
            banca.Clienti.Remove(client);
        }

        public void UpdateBankData(Banca banca, string newName, Adresa newAddress)
        {
            banca.Nume = newName;
            banca.AdresaBanca = newAddress;
        }

        public void DisplayClients(Banca banca)
        {
            foreach (var client in banca.Clienti)
            {
                Console.WriteLine($"Nume: {client.Nume}, Adresa: {client.AdresaClient.Strada}, {client.AdresaClient.Numar}, {client.AdresaClient.Apartament}, Tip Credit: {client.TipCredit}");
            }
        }

        public List<Client> FilterClients(Banca banca, string nume = null, string strada = null, int numar=0, int apartament=0, int tipCredit=0)
        {
            return banca.Clienti.Where(client =>
                (nume == null || client.Nume == nume) &&
                (strada == null || client.AdresaClient.Strada == strada) &&
                (numar == null || client.AdresaClient.Numar == numar) &&
                (apartament == null || client.AdresaClient.Apartament == apartament) &&
                (tipCredit == null || client.TipCredit == tipCredit)).ToList();
        }
    }
}


