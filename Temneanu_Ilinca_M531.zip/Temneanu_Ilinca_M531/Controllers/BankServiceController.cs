﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Temneanu_Ilinca_M531.Interfaces;

namespace Temneanu_Ilinca_M531.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class BankServiceController : ControllerBase
    {
        
        
            private readonly IBankService _bankService;
            private readonly IGeneralService _generalService;

            public BankServiceController(IBankService bankService, IGeneralService generalService)
            {
                _bankService = bankService;
                _generalService = generalService;
            }

            
        
    }
}
